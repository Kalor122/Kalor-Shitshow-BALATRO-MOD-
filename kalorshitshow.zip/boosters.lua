SMODS.Booster {
    key = 'hyper_standard_pack',
    loc_txt = {
        name = "Hyper Standard Pack",
        text = {
            "Get 10 playing cards"
        },
        group_name = "Hyper Standard Pack"
    },
    config = { extra = 10, choose = 10 },
    cost = 15,
    weight = 0.2,
    atlas = "CustomBoosters",
    pos = { x = 0, y = 0 },
    discovered = true,
    loc_vars = function(self, info_queue, card)
        local cfg = (card and card.ability) or self.config
        return {
            vars = { cfg.choose, cfg.extra }
        }
    end,
    create_card = function(self, card, i)
        return {
        set = "Playing Card",
            area = G.pack_cards,
            skip_materialize = true,
            soulable = true,
            key_append = "kalorshi_hyper_standard_pack"
        }
    end,
    ease_background_colour = function(self)
        ease_background_colour({ new_colour = HEX('2c2c2c') })
    end,
    particles = function(self)
        G.booster_pack_sparkles = Particles(1, 1, 0, 0, {
            timer = 0.015,
            scale = 0.3,
            initialize = true,
            lifespan = 3,
            speed = 0.2,
            padding = -1,
            attach = G.ROOM_ATTACH,
            colours = { G.C.BLACK, G.C.RED },
            fill = true
        })
        G.booster_pack_sparkles.fade_alpha = 1
        G.booster_pack_sparkles:fade(1, 0)
    end,
}


SMODS.Booster {
    key = 'jumbo_kalor_pack',
    loc_txt = {
        name = "Jumbo Kalor Pack",
        text = {
            "Choose 1 out of 4",
            "Kalor Shitshow Cards"
        },
        group_name = "Jumbo Kalor Pack"
    },
    config = { extra = 4, choose = 1 },
    cost = 7,
    weight = 0.8,
    atlas = "CustomBoosters",
    pos = { x = 1, y = 0 },
    discovered = true,
    loc_vars = function(self, info_queue, card)
        local cfg = (card and card.ability) or self.config
        return {
            vars = { cfg.choose, cfg.extra }
        }
    end,
    create_card = function(self, card, i)
        local selected_index = pseudorandom('kalorshi_jumbo_kalor_pack_card', 1, 3)
        if selected_index == 1 then
            return {
            set = "Joker",
            rarity = "kalorshi_kalor",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "kalorshi_jumbo_kalor_pack"
            }
        elseif selected_index == 2 then
            return {
            set = "Joker",
            rarity = "kalorshi_jabroni",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "kalorshi_jumbo_kalor_pack"
            }
        elseif selected_index == 3 then
            return {
            set = "Joker",
            rarity = "kalorshi_album",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "kalorshi_jumbo_kalor_pack"
            }
        end
    end,
    ease_background_colour = function(self)
        ease_background_colour({ new_colour = HEX('300056') })
    end,
    particles = function(self)
        -- No particles for joker packs
    end,
}


SMODS.Booster {
    key = 'jumbo_skull_pack',
    loc_txt = {
        name = "Jumbo Skull Pack",
        text = {
            "Choose 1 out of 4",
            "Skelington Cards"
        },
        group_name = "Jumbo Skull Pack"
    },
    config = { extra = 4, choose = 1 },
    cost = 5,
    weight = 0.8,
    atlas = "CustomBoosters",
    pos = { x = 2, y = 0 },
    draw_hand = true,
    select_card = "consumeables",
    discovered = true,
    loc_vars = function(self, info_queue, card)
        local cfg = (card and card.ability) or self.config
        return {
            vars = { cfg.choose, cfg.extra }
        }
    end,
    create_card = function(self, card, i)
        return {
        set = "skelington",
            area = G.pack_cards,
            skip_materialize = true,
            soulable = true,
            key_append = "kalorshi_jumbo_skull_pack"
        }
    end,
    ease_background_colour = function(self)
        ease_background_colour({ new_colour = HEX('4a4a4a') })
    end,
    particles = function(self)
        G.booster_pack_sparkles = Particles(1, 1, 0, 0, {
            timer = 0.015,
            scale = 0.2,
            initialize = true,
            lifespan = 1,
            speed = 1.1,
            padding = -1,
            attach = G.ROOM_ATTACH,
            colours = { G.C.WHITE, lighten(G.C.PURPLE, 0.4), lighten(G.C.PURPLE, 0.2), lighten(G.C.GOLD, 0.2) },
            fill = true
        })
        G.booster_pack_sparkles.fade_alpha = 1
        G.booster_pack_sparkles:fade(1, 0)
    end,
}


SMODS.Booster {
    key = 'kalor_pack',
    loc_txt = {
        name = "Kalor Pack",
        text = {
            "Choose 1 out of 3",
            "Kalor Shitshow Jokers"
        },
        group_name = "Kalor Pack"
    },
    config = { extra = 3, choose = 1 },
    cost = 6,
    weight = 0.8,
    atlas = "CustomBoosters",
    pos = { x = 3, y = 0 },
    discovered = true,
    loc_vars = function(self, info_queue, card)
        local cfg = (card and card.ability) or self.config
        return {
            vars = { cfg.choose, cfg.extra }
        }
    end,
    create_card = function(self, card, i)
        local selected_index = pseudorandom('kalorshi_kalor_pack_card', 1, 3)
        if selected_index == 1 then
            return {
            set = "Joker",
            rarity = "kalorshi_kalor",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "kalorshi_kalor_pack"
            }
        elseif selected_index == 2 then
            return {
            set = "Joker",
            rarity = "kalorshi_jabroni",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "kalorshi_kalor_pack"
            }
        elseif selected_index == 3 then
            return {
            set = "Joker",
            rarity = "kalorshi_album",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "kalorshi_kalor_pack"
            }
        end
    end,
    ease_background_colour = function(self)
        ease_background_colour({ new_colour = HEX('300056') })
    end,
    particles = function(self)
        -- No particles for joker packs
    end,
}


SMODS.Booster {
    key = 'mega_kalor_pack',
    loc_txt = {
        name = "Mega Kalor Pack",
        text = {
            "Choose 2 out of 6",
            "Kalor Shitshow Jokers"
        },
        group_name = "Mega Kalor Pack"
    },
    config = { extra = 6, choose = 2 },
    cost = 9,
    weight = 0.6,
    atlas = "CustomBoosters",
    pos = { x = 4, y = 0 },
    discovered = true,
    loc_vars = function(self, info_queue, card)
        local cfg = (card and card.ability) or self.config
        return {
            vars = { cfg.choose, cfg.extra }
        }
    end,
    create_card = function(self, card, i)
        local weights = {
            1,
            0.1,
            1,
            1
        }
        local total_weight = 0
        for _, weight in ipairs(weights) do
            total_weight = total_weight + weight
        end
        local random_value = pseudorandom('kalorshi_mega_kalor_pack_card') * total_weight
        local cumulative_weight = 0
        local selected_index = 1
        for j, weight in ipairs(weights) do
            cumulative_weight = cumulative_weight + weight
            if random_value <= cumulative_weight then
                selected_index = j
                break
            end
        end
        if selected_index == 1 then
            return {
            set = "Joker",
            rarity = "kalorshi_kalor",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "kalorshi_mega_kalor_pack"
            }
        elseif selected_index == 2 then
            return {
            set = "Joker",
            rarity = "kalorshi_super_kalor",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "kalorshi_mega_kalor_pack"
            }
        elseif selected_index == 3 then
            return {
            set = "Joker",
            rarity = "kalorshi_jabroni",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "kalorshi_mega_kalor_pack"
            }
        elseif selected_index == 4 then
            return {
            set = "Joker",
            rarity = "kalorshi_album",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "kalorshi_mega_kalor_pack"
            }
        end
    end,
    ease_background_colour = function(self)
        ease_background_colour({ new_colour = HEX('300056') })
    end,
    particles = function(self)
        -- No particles for joker packs
    end,
}


SMODS.Booster {
    key = 'mega_skull_pack',
    loc_txt = {
        name = "Mega Skull Pack",
        text = {
            "Choose 2 out of 6",
            "Skelington Cards"
        },
        group_name = "Mega Skull Pack"
    },
    config = { extra = 6, choose = 2 },
    cost = 7,
    weight = 0.6,
    atlas = "CustomBoosters",
    pos = { x = 5, y = 0 },
    draw_hand = true,
    select_card = "consumeables",
    discovered = true,
    loc_vars = function(self, info_queue, card)
        local cfg = (card and card.ability) or self.config
        return {
            vars = { cfg.choose, cfg.extra }
        }
    end,
    create_card = function(self, card, i)
        local weights = {
            2,
            1,
            0.5
        }
        local total_weight = 0
        for _, weight in ipairs(weights) do
            total_weight = total_weight + weight
        end
        local random_value = pseudorandom('kalorshi_mega_skull_pack_card') * total_weight
        local cumulative_weight = 0
        local selected_index = 1
        for j, weight in ipairs(weights) do
            cumulative_weight = cumulative_weight + weight
            if random_value <= cumulative_weight then
                selected_index = j
                break
            end
        end
        if selected_index == 1 then
            return {
            set = "skelington",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "kalorshi_mega_skull_pack"
            }
        elseif selected_index == 2 then
            return {
            set = "skelington",
            edition = "e_negative",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "kalorshi_mega_skull_pack"
            }
        elseif selected_index == 3 then
            return {
            set = "super_skelington",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "kalorshi_mega_skull_pack"
            }
        end
    end,
    ease_background_colour = function(self)
        ease_background_colour({ new_colour = HEX('430000') })
    end,
    particles = function(self)
        G.booster_pack_sparkles = Particles(1, 1, 0, 0, {
            timer = 0.015,
            scale = 0.2,
            initialize = true,
            lifespan = 1,
            speed = 1.1,
            padding = -1,
            attach = G.ROOM_ATTACH,
            colours = { G.C.WHITE, lighten(G.C.PURPLE, 0.4), lighten(G.C.PURPLE, 0.2), lighten(G.C.GOLD, 0.2) },
            fill = true
        })
        G.booster_pack_sparkles.fade_alpha = 1
        G.booster_pack_sparkles:fade(1, 0)
    end,
}


SMODS.Booster {
    key = 'skull_pack',
    loc_txt = {
        name = "Skull Pack",
        text = {
            "Choose 1 out of 3",
            "Skelington Cards"
        },
        group_name = "Skull Pack"
    },
    config = { extra = 3, choose = 1 },
    atlas = "CustomBoosters",
    pos = { x = 6, y = 0 },
    draw_hand = true,
    select_card = "consumeables",
    discovered = true,
    loc_vars = function(self, info_queue, card)
        local cfg = (card and card.ability) or self.config
        return {
            vars = { cfg.choose, cfg.extra }
        }
    end,
    create_card = function(self, card, i)
        return {
        set = "skelington",
            area = G.pack_cards,
            skip_materialize = true,
            soulable = true,
            key_append = "kalorshi_skull_pack"
        }
    end,
    ease_background_colour = function(self)
        ease_background_colour({ new_colour = HEX('4a4a4a') })
    end,
    particles = function(self)
        G.booster_pack_sparkles = Particles(1, 1, 0, 0, {
            timer = 0.015,
            scale = 0.2,
            initialize = true,
            lifespan = 1,
            speed = 1.1,
            padding = -1,
            attach = G.ROOM_ATTACH,
            colours = { G.C.WHITE, lighten(G.C.PURPLE, 0.4), lighten(G.C.PURPLE, 0.2), lighten(G.C.GOLD, 0.2) },
            fill = true
        })
        G.booster_pack_sparkles.fade_alpha = 1
        G.booster_pack_sparkles:fade(1, 0)
    end,
}
