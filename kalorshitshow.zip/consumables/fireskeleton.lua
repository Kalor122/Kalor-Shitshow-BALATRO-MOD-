SMODS.Consumable {
    key = 'fireskeleton',
    set = 'skelington',
    pos = { x = 6, y = 0 },
    loc_txt = {
        name = 'Fire Skeleton',
        text = {
        [1] = '{C:hearts}Destroys{} up to {C:attention}3{} selected cards'
    }
    },
    cost = 4,
    unlocked = true,
    discovered = true,
    hidden = false,
    can_repeat_soul = false,
    atlas = 'CustomConsumables',
    use = function(self, card, area, copier)
        local used_card = copier or card
        if (#G.hand.highlighted <= 3 and #G.hand.highlighted >= 1 and G.GAME.blind.in_blind) then
            G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.4,
                func = function()
                    play_sound('tarot1')
                    used_card:juice_up(0.3, 0.5)
                    return true
                end
            }))
            G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.2,
                func = function()
                    SMODS.destroy_cards(G.hand.highlighted)
                    return true
                end
            }))
            delay(0.3)
        end
    end,
    can_use = function(self, card)
        return ((#G.hand.highlighted <= 3 and #G.hand.highlighted >= 1 and G.GAME.blind.in_blind))
    end
}