SMODS.Consumable {
    key = 'skeletonsuicide',
    set = 'super_skelington',
    pos = { x = 9, y = 1 },
    config = { extra = {
        hands_value = 0,
        discards_value = 0
    } },
    loc_txt = {
        name = 'Skeleton Suicide',
        text = {
        [1] = '{C:hearts}Die.{}'
    }
    },
    cost = 10,
    unlocked = true,
    discovered = true,
    hidden = false,
    can_repeat_soul = false,
    atlas = 'CustomConsumables',
    use = function(self, card, area, copier)
        local used_card = copier or card
            local mod = 0 - G.GAME.round_resets.hands
            G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.4,
                func = function()
                    card_eval_status_text(used_card, 'extra', nil, nil, nil, {message = "NYEH!!", colour = G.C.BLUE})
                    
        G.GAME.round_resets.hands = 0
        ease_hands_played(0 - G.GAME.current_round.hands_left)
        
                    return true
                end
            }))
            delay(0.6)
            local mod = 0 - G.GAME.round_resets.discards
            G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.4,
                func = function()
                    card_eval_status_text(used_card, 'extra', nil, nil, nil, {message = "NYEH!!", colour = G.C.BLUE})
                    
        G.GAME.round_resets.discards = 0
        ease_discard(0 - G.GAME.current_round.discards_left)
        
                    return true
                end
            }))
            delay(0.6)
    end,
    can_use = function(self, card)
        return true
    end
}