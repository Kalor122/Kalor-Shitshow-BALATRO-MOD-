SMODS.Consumable {
    key = 'skeletonbusinessmeeting',
    set = 'super_skelington',
    pos = { x = 5, y = 1 },
    config = { extra = {
        money÷5 = 0
    } },
    loc_txt = {
        name = 'Skeleton Business Meeting',
        text = {
        [1] = 'This is a {C:hearts}VERY{} important Skeleton business meeting',
        [2] = '+1 {C:clubs}Hand{} for every {C:money}5${} you have permanently',
        [3] = 'Doesn\'t take away {C:money}money{}'
    }
    },
    cost = 5,
    unlocked = true,
    discovered = true,
    hidden = false,
    can_repeat_soul = false,
    atlas = 'CustomConsumables',
    use = function(self, card, area, copier)
        local used_card = copier or card
            G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.4,
                func = function()
                    card_eval_status_text(used_card, 'extra', nil, nil, nil, {message = "NYEH!!", colour = G.C.GREEN})
                    
        G.GAME.round_resets.hands = G.GAME.round_resets.hands + math.floor(lenient_bignum(G.GAME.dollars / 5))
        ease_hands_played(math.floor(lenient_bignum(G.GAME.dollars / 5)))
        
                    return true
                end
            }))
            delay(0.6)
    end,
    can_use = function(self, card)
        return true
    end
}