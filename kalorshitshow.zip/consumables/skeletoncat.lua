SMODS.Consumable {
    key = 'skeletoncat',
    set = 'super_skelington',
    pos = { x = 6, y = 1 },
    loc_txt = {
        name = 'Skeleton Cat',
        text = {
        [1] = 'Creates {C:attention}2{} {C:dark_edition}negative{} {C:attention}Copycats{}'
    }
    },
    cost = 12,
    unlocked = true,
    discovered = true,
    hidden = false,
    can_repeat_soul = false,
    atlas = 'CustomConsumables',
    use = function(self, card, area, copier)
        local used_card = copier or card
            G.E_MANAGER:add_event(Event({
                  trigger = 'after',
                  delay = 0.4,
                  func = function()
                      play_sound('timpani')
                      local new_joker = SMODS.add_card({ set = 'Joker', key = 'j_kalorshi_copycat' })
                      if new_joker then
                          new_joker:set_edition({ negative = true }, true)
                      end
                      used_card:juice_up(0.3, 0.5)
                      return true
                  end
              }))
              delay(0.6)
            G.E_MANAGER:add_event(Event({
                  trigger = 'after',
                  delay = 0.4,
                  func = function()
                      play_sound('timpani')
                      local new_joker = SMODS.add_card({ set = 'Joker', key = 'j_kalorshi_copycat' })
                      if new_joker then
                          new_joker:set_edition({ negative = true }, true)
                      end
                      used_card:juice_up(0.3, 0.5)
                      return true
                  end
              }))
              delay(0.6)
    end,
    can_use = function(self, card)
        return true
    end
}