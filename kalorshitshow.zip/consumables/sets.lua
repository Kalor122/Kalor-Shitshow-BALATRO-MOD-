SMODS.ConsumableType {
    key = 'skelington',
    primary_colour = HEX('9b9b9b'),
    secondary_colour = HEX('9b9b9b'),
    collection_rows = { 4, 5 },
    shop_rate = 1,
    cards = {
        ['c_kalorshi_alberteinskeleton'] = true,
        ['c_kalorshi_austronautskeleton'] = true,
        ['c_kalorshi_baldskeleton'] = true,
        ['c_kalorshi_businessskelington'] = true,
        ['c_kalorshi_crystalskeleton'] = true,
        ['c_kalorshi_fireskeleton'] = true,
        ['c_kalorshi_greenskeleton'] = true,
        ['c_kalorshi_grimreaper'] = true,
        ['c_kalorshi_iceskeleton'] = true,
        ['c_kalorshi_skeleton'] = true,
        ['c_kalorshi_skeletonking'] = true,
        ['c_kalorshi_skeletonsalesman'] = true,
        ['c_kalorshi_skeletonwarrior'] = true,
        ['c_kalorshi_skeletonsinyourcloset'] = true,
        ['c_kalorshi_theskull'] = true
    },
    loc_txt = {
        name = "Skelington",
        collection = "Skelington Cards",
    }
}

SMODS.ConsumableType {
    key = 'super_skelington',
    shader = 'spectral',
    primary_colour = HEX('4a4a4a'),
    secondary_colour = HEX('4a4a4a'),
    collection_rows = { 4, 5 },
    shop_rate = 0.2,
    cards = {
        ['c_kalorshi_alienskeleton'] = true,
        ['c_kalorshi_iceskeletonking'] = true,
        ['c_kalorshi_llukseht'] = true,
        ['c_kalorshi_sanstheskeleton'] = true,
        ['c_kalorshi_satanicgrimreaper'] = true,
        ['c_kalorshi_skeletonbusinessmeeting'] = true,
        ['c_kalorshi_skeletoncat'] = true,
        ['c_kalorshi_skeletonsuicide'] = true,
        ['c_kalorshi_theskeletonappears'] = true
    },
    loc_txt = {
        name = "SUPER Skelington",
        collection = "SUPER Skelington Cards",
    }
}