SMODS.Consumable {
    key = 'llukseht',
    set = 'super_skelington',
    pos = { x = 1, y = 1 },
    loc_txt = {
        name = 'llukS ehT',
        text = {
        [1] = 'Create a random {C:dark_edition}SUPER Kalor{} joker'
    }
    },
    cost = 15,
    unlocked = true,
    discovered = true,
    hidden = false,
    can_repeat_soul = false,
    atlas = 'CustomConsumables',
    use = function(self, card, area, copier)
        local used_card = copier or card
            G.E_MANAGER:add_event(Event({
                  trigger = 'after',
                  delay = 0.4,
                  func = function()
                      play_sound('timpani')
                      SMODS.add_card({ set = 'Joker', rarity = 'kalorshi_super_kalor' })
                      used_card:juice_up(0.3, 0.5)
                      return true
                  end
              }))
              delay(0.6)
    end,
    can_use = function(self, card)
        return true
    end
}