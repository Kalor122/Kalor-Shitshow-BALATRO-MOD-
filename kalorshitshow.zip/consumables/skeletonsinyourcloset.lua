SMODS.Consumable {
    key = 'skeletonsinyourcloset',
    set = 'skelington',
    pos = { x = 1, y = 2 },
    config = { extra = {
        consumable_count = 1,
        odds = 4
    } },
    loc_txt = {
        name = 'Skeletons In Your Closet',
        text = {
        [1] = 'Creates a {C:attention}Skelington{} card',
        [2] = '{C:green}1 in 4{} chance to create',
        [3] = 'another {C:attention}Skelington{} card'
    }
    },
    cost = 4,
    unlocked = true,
    discovered = true,
    hidden = false,
    can_repeat_soul = false,
    atlas = 'CustomConsumables',
    use = function(self, card, area, copier)
        local used_card = copier or card
            for i = 1, math.min(1, G.consumeables.config.card_limit - #G.consumeables.cards) do
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.4,
                    func = function()
                        if G.consumeables.config.card_limit > #G.consumeables.cards then
                            play_sound('timpani')
                            SMODS.add_card({ set = 'skelington' })
                            used_card:juice_up(0.3, 0.5)
                        end
                        return true
                    end
                }))
            end
            delay(0.6)
            if SMODS.pseudorandom_probability(card, 'group_0_70da6e55', 1, card.ability.extra.odds, 'c_kalorshi') then
                for i = 1, math.min(1, G.consumeables.config.card_limit - #G.consumeables.cards) do
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.4,
                    func = function()
                        if G.consumeables.config.card_limit > #G.consumeables.cards then
                            play_sound('timpani')
                            SMODS.add_card({ set = 'skelington' })
                            used_card:juice_up(0.3, 0.5)
                        end
                        return true
                    end
                }))
            end
            delay(0.6)
            end
    end,
    can_use = function(self, card)
        return true
    end
}