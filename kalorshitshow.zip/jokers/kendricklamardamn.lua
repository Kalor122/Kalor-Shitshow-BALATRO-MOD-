SMODS.Joker{ --Kendrick Lamar - DAMN.
    key = "kendricklamardamn",
    config = {
        extra = {
            chips = 0,
            mult = 0
        }
    },
    loc_txt = {
        ['name'] = 'Kendrick Lamar - DAMN.',
        ['text'] = {
            [1] = '{C:hearts}GAINS 2 CHIPS AND 2 MULT EVERY ROUND.{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 7,
        y = 1
    },
    cost = 5,
    rarity = "kalorshi_album",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.setting_blind  then
                return {
                    func = function()
                    card.ability.extra.chips = (card.ability.extra.chips) + 2
                    return true
                end,
                    message = "DAMN.",
                    extra = {
                        func = function()
                    card.ability.extra.mult = (card.ability.extra.mult) + 2
                    return true
                end,
                        colour = G.C.GREEN
                        }
                }
        end
    end
}