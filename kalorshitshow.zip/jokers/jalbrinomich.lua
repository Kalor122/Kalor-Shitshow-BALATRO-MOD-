SMODS.Joker{ --Jalbrino Mich
    key = "jalbrinomich",
    config = {
        extra = {
            sell_value = 5
        }
    },
    loc_txt = {
        ['name'] = 'Jalbrino Mich',
        ['text'] = {
            [1] = 'Smooth like an {C:attention}egg{}',
            [2] = '{C:money}+5${} to it\'s sell value',
            [3] = 'at the start of round'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 1,
        y = 1
    },
    cost = 7,
    rarity = "kalorshi_jabroni",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.setting_blind  then
                return {
                    func = function()
            card.ability.extra_value = (card.ability.extra_value or 0) + card.ability.extra.sell_value
            card:set_cost()
                    return true
                end,
                    message = "BALD!"
                }
        end
    end
}