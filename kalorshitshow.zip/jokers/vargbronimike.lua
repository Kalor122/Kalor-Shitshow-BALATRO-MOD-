SMODS.Joker{ --Vargbroni Mike
    key = "vargbronimike",
    config = {
        extra = {
            mult = 10,
            mult2 = 50
        }
    },
    loc_txt = {
        ['name'] = 'Vargbroni Mike',
        ['text'] = {
            [1] = '{C:red}+10{} Mult',
            [2] = 'If there\'s another',
            [3] = '{C:attention}Jabroni{} joker, {C:red}+50{} Mult'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 1,
        y = 4
    },
    cost = 5,
    rarity = "kalorshi_jabroni",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if (function()
    local count = 0
    for _, joker_owned in pairs(G.jokers.cards or {}) do
        if joker_owned.config.center.rarity == "kalorshi_jabroni" then
            count = count + 1
        end
    end
    return count == 1
end)() then
                return {
                    mult = card.ability.extra.mult
                }
            elseif (function()
    local count = 0
    for _, joker_owned in pairs(G.jokers.cards or {}) do
        if joker_owned.config.center.rarity == "kalorshi_jabroni" then
            count = count + 1
        end
    end
    return count > 1
end)() then
                return {
                    mult = card.ability.extra.mult2
                }
            end
        end
    end
}