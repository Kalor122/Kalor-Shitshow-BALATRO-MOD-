SMODS.Joker{ --System Of A Down - System Of A Down
    key = "systemofadownsystemofadown",
    config = {
        extra = {
            odds = 5,
            Xmult = 5
        }
    },
    loc_txt = {
        ['name'] = 'System Of A Down - System Of A Down',
        ['text'] = {
            [1] = '{C:green}1 in 5{} for {X:red,C:white}X5{} Mult'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 4,
        y = 3
    },
    cost = 10,
    rarity = "kalorshi_album",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if true then
                if SMODS.pseudorandom_probability(card, 'group_0_9f35ca9d', 1, card.ability.extra.odds, 'j_kalorshi_systemofadownsystemofadown') then
                      SMODS.calculate_effect({Xmult = card.ability.extra.Xmult}, card)
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Know!", colour = G.C.WHITE})
                  end
            end
        end
    end
}