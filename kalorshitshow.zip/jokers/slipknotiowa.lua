SMODS.Joker{ --Slipknot - Iowa
    key = "slipknotiowa",
    config = {
        extra = {
            xchips = 2.515,
            odds = 5
        }
    },
    loc_txt = {
        ['name'] = 'Slipknot - Iowa',
        ['text'] = {
            [1] = 'Every {C:attention}face{} card in scored hand',
            [2] = 'gives {X:red,C:white}X2.515{} Mult',
            [3] = '{C:green}1 in 5{} chance to',
            [4] = 'be {C:hearts}Left Behind{} {C:inactive}(destroyed){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 2,
        y = 3
    },
    cost = 5,
    rarity = "kalorshi_album",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.destroy_card and context.destroy_card.should_destroy  then
            return { remove = true }
        end
        if context.individual and context.cardarea == G.play  then
            context.other_card.should_destroy = false
            if context.other_card:is_face() then
                return {
                    x_chips = card.ability.extra.xchips
                ,
                    func = function()
                        if SMODS.pseudorandom_probability(card, 'group_0_0715f8e1', 1, card.ability.extra.odds, 'j_kalorshi_slipknotiowa') then
                      context.other_card.should_destroy = true
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Ive seen faces that have disappeared in time...", colour = G.C.RED})
                  end
                        return true
                    end
                }
            end
        end
    end
}