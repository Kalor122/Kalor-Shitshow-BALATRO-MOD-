SMODS.Joker{ --Lanzapapeadas
    key = "lanzapapeadas",
    config = {
        extra = {
            mult = 0,
            hasomar = 0
        }
    },
    loc_txt = {
        ['name'] = 'Lanzapapeadas',
        ['text'] = {
            [1] = '{C:red}+1{} Mult for every discarded card',
            [2] = '{C:red}+2{} if you also own {C:attention}Omar{}',
            [3] = '{C:inactive}(Current: {C:red}+#1#{} {C:inactive}Mult){}{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 8,
        y = 1
    },
    cost = 7,
    rarity = "kalorshi_kalor",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.mult}}
    end,

    calculate = function(self, card, context)
        if context.discard  then
            if (card.ability.extra.hasomar or 0) == 0 then
                return {
                    func = function()
                    card.ability.extra.mult = (card.ability.extra.mult) + 1
                    return true
                end,
                    message = "+1"
                }
            elseif (card.ability.extra.hasomar or 0) == 1 then
                return {
                    func = function()
                    card.ability.extra.mult = (card.ability.extra.mult) + 2
                    return true
                end,
                    message = "+2"
                }
            end
        end
        if context.setting_blind  then
            if (function()
      for i = 1, #G.jokers.cards do
          if G.jokers.cards[i].config.center.key == "j_kalorshi_omar" then
              return true
          end
      end
      return false
  end)() then
                return {
                    func = function()
                    card.ability.extra.hasomar = 1
                    return true
                end
                }
            elseif not ((function()
      for i = 1, #G.jokers.cards do
          if G.jokers.cards[i].config.center.key == "j_kalorshi_omar" then
              return true
          end
      end
      return false
  end)()) then
                return {
                    func = function()
                    card.ability.extra.hasomar = 0
                    return true
                end
                }
            end
        end
        if context.cardarea == G.jokers and context.joker_main  then
                return {
                    mult = card.ability.extra.mult
                }
        end
    end
}