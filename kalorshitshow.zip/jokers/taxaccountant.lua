SMODS.Joker{ --Tax Accountant
    key = "taxaccountant",
    config = {
        extra = {
            counter = 0,
            dollars = 20,
            emult = 2
        }
    },
    loc_txt = {
        ['name'] = 'Tax Accountant',
        ['text'] = {
            [1] = '{X:tarot,C:white}^2{} Mult',
            [2] = 'But you\'ll have to pay',
            [3] = '{C:money}20${} every boss blind',
            [4] = 'If you don\'t meet',
            [5] = 'the quota, you {C:hearts}die{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 5,
        y = 3
    },
    cost = 3,
    rarity = "kalorshi_kalor",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    in_pool = function(self, args)
          return (
          not args 
            
          or args.source == 'sho' or args.source == 'buf' or args.source == 'jud' or args.source == 'rif' or args.source == 'rta' or args.source == 'sou' or args.source == 'uta' or args.source == 'wra'
          )
          and G.GAME.pool_flags.kalorshi_tax_evasion
      end,

    set_ability = function(self, card, initial)
        card:set_eternal(true)
    end,

    calculate = function(self, card, context)
        if context.end_of_round and context.game_over == false and context.main_eval  then
                return {
                    func = function()
                    card.ability.extra.counter = (card.ability.extra.counter) + 1
                    return true
                end
                }
        end
        if context.setting_blind  then
            if ((card.ability.extra.counter or 0) == 2 and G.GAME.dollars >= to_big(20) and not ((G.GAME.pool_flags.kalorshi_tax_evasion or false))) then
                return {
                    dollars = -card.ability.extra.dollars,
                    extra = {
                        func = function()
                    card.ability.extra.counter = 0
                    return true
                end,
                        colour = G.C.BLUE
                        }
                }
            elseif ((card.ability.extra.counter or 0) == 2 and not (G.GAME.dollars >= to_big(20)) and not ((G.GAME.pool_flags.kalorshi_tax_evasion or false))) then
                return {
                    func = function()
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "You did not meet the quota", colour = G.C.RED})
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.5,
                    func = function()
                        if G.STAGE == G.STAGES.RUN then 
                          G.STATE = G.STATES.GAME_OVER
                          G.STATE_COMPLETE = false
                        end
                    end
                }))
                
                return true
            end
                }
            end
        end
        if context.cardarea == G.jokers and context.joker_main  then
                return {
                    e_mult = card.ability.extra.emult
                }
        end
    end
}