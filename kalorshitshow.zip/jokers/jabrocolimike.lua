SMODS.Joker{ --Jabrocoli Mike
    key = "jabrocolimike",
    config = {
        extra = {
            xchips = 1.5
        }
    },
    loc_txt = {
        ['name'] = 'Jabrocoli Mike',
        ['text'] = {
            [1] = 'If scored card is a {C:clubs}Club{}',
            [2] = '{X:blue,C:white}X1.5{} Chips'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 8,
        y = 0
    },
    cost = 5,
    rarity = "kalorshi_jabroni",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if context.other_card:is_suit("Clubs") then
                return {
                    x_chips = card.ability.extra.xchips
                }
            end
        end
    end
}