SMODS.Joker{ --MrBean Sex Jackass
    key = "mrbeansexjackass",
    config = {
        extra = {
            respect = 0
        }
    },
    loc_txt = {
        ['name'] = 'MrBean Sex Jackass',
        ['text'] = {
            [1] = '{C:attention}Fucks{} joker to the right,',
            [2] = 'creating a {C:dark_edition}negative {}copy of it',
            [3] = '{C:inactive}(If there\'s space){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 7,
        y = 2
    },
    cost = 13,
    rarity = "kalorshi_super_kalor",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.end_of_round and context.game_over == false and context.main_eval  then
                return {
                    func = function()
                local my_pos = nil
                for i = 1, #G.jokers.cards do
                    if G.jokers.cards[i] == card then
                        my_pos = i
                        break
                    end
                end
                local target_joker = (my_pos and my_pos > 1) and G.jokers.cards[my_pos - 1] or nil
                
                if target_joker and #G.jokers.cards + G.GAME.joker_buffer < G.jokers.config.card_limit then
                        G.GAME.joker_buffer = G.GAME.joker_buffer + 1
                    G.E_MANAGER:add_event(Event({
                        func = function()
                            local copied_joker = copy_card(target_joker, nil, nil, nil, target_joker.edition and target_joker.edition.negative)
                            
                            copied_joker:add_to_deck()
                            G.jokers:emplace(copied_joker)
                        G.GAME.joker_buffer = 0
                            return true
                        end
                    }))
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Eeeuuuuughhhh,,,", colour = G.C.GREEN})
                end
                    return true
                end
                }
        end
    end
}