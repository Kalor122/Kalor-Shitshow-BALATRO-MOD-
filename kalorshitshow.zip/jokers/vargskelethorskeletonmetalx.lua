SMODS.Joker{ --Vargskelethor - Skeleton Metal X
    key = "vargskelethorskeletonmetalx",
    config = {
        extra = {
            chips = 0
        }
    },
    loc_txt = {
        ['name'] = 'Vargskelethor - Skeleton Metal X',
        ['text'] = {
            [1] = 'Gains {C:blue}+50{} Chips every time you use a',
            [2] = '{C:attention}Skelington{} or {C:dark_edition}SUPER Skelington{} card',
            [3] = '{C:inactive}(Current: {C:blue}+#1#{} {C:inactive}Chips){}{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 2,
        y = 4
    },
    cost = 5,
    rarity = "kalorshi_album",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.chips}}
    end,

    calculate = function(self, card, context)
        if context.using_consumeable  then
            if (context.consumeable and (context.consumeable.ability.set == 'skelington' or context.consumeable.ability.set == 'skelington') or context.consumeable and (context.consumeable.ability.set == 'skelington' or context.consumeable.ability.set == 'super_skelington')) then
                return {
                    func = function()
                    card.ability.extra.chips = (card.ability.extra.chips) + 50
                    return true
                end,
                    message = "NYEH!!"
                }
            end
        end
        if context.cardarea == G.jokers and context.joker_main  then
                return {
                    chips = card.ability.extra.chips
                }
        end
    end
}