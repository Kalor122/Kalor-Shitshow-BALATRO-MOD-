SMODS.Joker{ --Jorbius Morbius
    key = "jorbiusmorbius",
    config = {
        extra = {
            echips = 1.2
        }
    },
    loc_txt = {
        ['name'] = 'Jorbius Morbius',
        ['text'] = {
            [1] = 'Mr. Morbius uses his {C:attention}morbological ecolocation{}',
            [2] = 'to carefully extract the {C:attention}fecal particules{} of his body {C:inactive}(???)',
            [3] = '{}{X:spectral,C:white}^1.2{} Chips when your {C:attention}least played hand{} is played'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 3,
        y = 1
    },
    cost = 5,
    rarity = "kalorshi_jabroni",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if (function()
    local current_played = G.GAME.hands[context.scoring_name].played or 0
    for handname, values in pairs(G.GAME.hands) do
        if handname ~= context.scoring_name and values.played < current_played and values.visible then
            return false
        end
    end
    return true
end)() then
                return {
                    e_chips = card.ability.extra.echips,
                    message = "I am a doctor"
                }
            end
        end
    end
}