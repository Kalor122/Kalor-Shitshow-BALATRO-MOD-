SMODS.Joker{ --Omar
    key = "omar",
    config = {
        extra = {
            chips = 0,
            haslanza = 0
        }
    },
    loc_txt = {
        ['name'] = 'Omar',
        ['text'] = {
            [1] = '{C:blue}+1{} Chips for every discarded card',
            [2] = '{C:blue}+2{} if you also own {C:attention}Lanzapapeadas{}',
            [3] = '{C:inactive}(Current: {C:blue}+#1#{} {C:inactive}Chips){}{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 0,
        y = 3
    },
    cost = 7,
    rarity = "kalorshi_kalor",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.chips}}
    end,

    calculate = function(self, card, context)
        if context.discard  then
            if (card.ability.extra.haslanza or 0) == 0 then
                return {
                    func = function()
                    card.ability.extra.chips = (card.ability.extra.chips) + 1
                    return true
                end,
                    message = "+1"
                }
            elseif (card.ability.extra.haslanza or 0) == 1 then
                return {
                    func = function()
                    card.ability.extra.chips = (card.ability.extra.chips) + 2
                    return true
                end,
                    message = "+2"
                }
            end
        end
        if context.setting_blind  then
            if (function()
      for i = 1, #G.jokers.cards do
          if G.jokers.cards[i].config.center.key == "j_kalorshi_lanzapapeadas" then
              return true
          end
      end
      return false
  end)() then
                return {
                    func = function()
                    card.ability.extra.haslanza = 1
                    return true
                end
                }
            elseif not ((function()
      for i = 1, #G.jokers.cards do
          if G.jokers.cards[i].config.center.key == "j_kalorshi_lanzapapeadas" then
              return true
          end
      end
      return false
  end)()) then
                return {
                    func = function()
                    card.ability.extra.haslanza = 0
                    return true
                end
                }
            end
        end
        if context.cardarea == G.jokers and context.joker_main  then
                return {
                    chips = card.ability.extra.chips
                }
        end
    end
}