SMODS.Joker{ --Nickelback - All The Right Reasons
    key = "nickelbackalltherightreasons",
    config = {
        extra = {
            Xmult = 3.5
        }
    },
    loc_txt = {
        ['name'] = 'Nickelback - All The Right Reasons',
        ['text'] = {
            [1] = '{X:red,C:white}X3.5{} Mult if you own {C:attention}Photograph{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 9,
        y = 2
    },
    cost = 5,
    rarity = "kalorshi_album",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if (function()
      for i = 1, #G.jokers.cards do
          if G.jokers.cards[i].config.center.key == "j_photograph" then
              return true
          end
      end
      return false
  end)() then
                return {
                    Xmult = card.ability.extra.Xmult,
                    message = "Look at this photograph"
                }
            end
        end
    end
}