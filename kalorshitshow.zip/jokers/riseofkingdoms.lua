SMODS.Joker{ --Rise of Kingdoms
    key = "riseofkingdoms",
    config = {
        extra = {
            power = 1000,
            power_out = 1000
        }
    },
    loc_txt = {
        ['name'] = 'Rise of Kingdoms',
        ['text'] = {
            [1] = 'Starts with {C:blue}1000{} power, increments every round',
            [2] = 'Gives {X:red,C:white}Xmult{} {C:inactive}(Xmult = Power / 1000){}',
            [3] = '{C:inactive}(Current: {C:blue}#1#{} {C:inactive}Power){}{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 1,
        y = 3
    },
    cost = 7,
    rarity = "kalorshi_kalor",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.power}}
    end,

    calculate = function(self, card, context)
        if context.setting_blind  then
                return {
                    func = function()
                    card.ability.extra.power = (card.ability.extra.power) + pseudorandom('power_60deaee9', 100, 500)
                    return true
                end,
                    message = "Power up!"
                }
        end
        if context.cardarea == G.jokers and context.joker_main  then
                local power_out_value = card.ability.extra.power_out
                card.ability.extra.power_out = card.ability.extra.power
                card.ability.extra.power_out = (card.ability.extra.power_out) / 1000
                return {
                    Xmult = power_out_value
                }
        end
    end
}