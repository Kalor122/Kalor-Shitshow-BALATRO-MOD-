SMODS.Joker{ --Jabroni Mike
    key = "jabronimike",
    config = {
        extra = {
            chips = 10,
            mult = 5
        }
    },
    loc_txt = {
        ['name'] = 'Jabroni Mike',
        ['text'] = {
            [1] = 'Mike {C:attention}shits himself{}, giving',
            [2] = '{C:blue}+10{} Chips and {C:red}+5{} Mult'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 9,
        y = 0
    },
    cost = 4,
    rarity = "kalorshi_jabroni",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
                return {
                    chips = card.ability.extra.chips,
                    extra = {
                        mult = card.ability.extra.mult
                        }
                }
        end
    end
}