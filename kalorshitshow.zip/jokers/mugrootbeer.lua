SMODS.Joker{ --MUG Root Beer
    key = "mugrootbeer",
    config = {
        extra = {
            emult = 1.2
        }
    },
    loc_txt = {
        ['name'] = 'MUG Root Beer',
        ['text'] = {
            [1] = '{C:attention}I LOVE MY MUG ROOT BEER{}',
            [2] = '{X:tarot,C:white}^1.2{} Mult'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 8,
        y = 2
    },
    cost = 6,
    rarity = "kalorshi_kalor",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
                return {
                    e_mult = card.ability.extra.emult
                }
        end
    end
}