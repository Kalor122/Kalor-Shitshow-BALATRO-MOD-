SMODS.Joker{ --Hatsune Miku
    key = "hatsunemiku",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = 'Hatsune Miku',
        ['text'] = {
            [1] = 'Gives {C:dark_edition}Holographic{} to every card is scored hand'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 7,
        y = 0
    },
    cost = 9,
    rarity = "kalorshi_kalor",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    set_ability = function(self, card, initial)
        card:set_edition("e_holo", true)
    end,

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
                context.other_card:set_edition("e_holo", true)
                return {
                    message = "PoPiPo"
                }
        end
    end
}