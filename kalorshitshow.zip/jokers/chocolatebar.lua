SMODS.Joker{ --Chocolate Bar
    key = "chocolatebar",
    config = {
        extra = {
            odds = 6,
            scale = 1,
            rotation = 1,
            onetime = 0
        }
    },
    loc_txt = {
        ['name'] = 'Chocolate Bar',
        ['text'] = {
            [1] = '{C:green}1 in 6{} chance to give',
            [2] = '{C:enhanced}Chocolate{} to scored card'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 2,
        y = 0
    },
    cost = 7,
    rarity = "kalorshi_kalor",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if true then
                if SMODS.pseudorandom_probability(card, 'group_0_b94ac62a', 1, card.ability.extra.odds, 'j_kalorshi_chocolatebar') then
                      context.other_card:set_ability(G.P_CENTERS.m_kalorshi_chocolate)
                        local target_card = context.other_card
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Card Modified!", colour = G.C.BLUE})
                        SMODS.calculate_effect({func = function()
                      target_card:juice_up(card.ability.extra.scale, card.ability.extra.rotation)
                      return true
                    end}, card)
                  end
            end
        end
    end
}