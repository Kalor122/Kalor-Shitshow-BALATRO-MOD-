SMODS.Joker{ --Michael of Jabronos
    key = "michaelofjabronos",
    config = {
        extra = {
            Xmult = 1.5
        }
    },
    loc_txt = {
        ['name'] = 'Michael of Jabronos',
        ['text'] = {
            [1] = 'the curse of the witch caused the',
            [2] = 'man to having the no of hair, but the yes of {X:red,C:white}Xmult{}',
            [3] = '{X:red,C:white}X1.5{} Mult'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 5,
        y = 2
    },
    cost = 5,
    rarity = "kalorshi_jabroni",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
                return {
                    Xmult = card.ability.extra.Xmult
                }
        end
    end
}