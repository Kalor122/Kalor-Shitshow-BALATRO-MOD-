SMODS.Joker{ --Divorce Funky Kong
    key = "divorcefunkykong",
    config = {
        extra = {
            haspair = 0,
            Xmult = 1.5
        }
    },
    loc_txt = {
        ['name'] = 'Divorce Funky Kong',
        ['text'] = {
            [1] = '{X:red,C:white}X1.5{} Mult if played hand',
            [2] = '{C:red}does not{} contain a {C:attention}Pair{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 5,
        y = 0
    },
    cost = 6,
    rarity = "kalorshi_kalor",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if (card.ability.extra.haspair or 0) == 0 then
                return {
                    Xmult = card.ability.extra.Xmult
                }
            end
        end
        if context.before and context.cardarea == G.jokers  then
            if next(context.poker_hands["Pair"]) then
                return {
                    func = function()
                    card.ability.extra.haspair = 1
                    return true
                end
                }
            end
        end
    end
}