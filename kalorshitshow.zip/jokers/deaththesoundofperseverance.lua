SMODS.Joker{ --Death - The Sound Of Perseverance
    key = "deaththesoundofperseverance",
    config = {
        extra = {
            Xmult = 1.5
        }
    },
    loc_txt = {
        ['name'] = 'Death - The Sound Of Perseverance',
        ['text'] = {
            [1] = 'Every {C:attention}7{} in scored hand gives {X:red,C:white}X1.5{} Mult'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 4,
        y = 0
    },
    cost = 7,
    rarity = "kalorshi_album",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if context.other_card:get_id() == 7 then
                return {
                    Xmult = card.ability.extra.Xmult,
                    message = "Spirit Crusher!"
                }
            end
        end
    end
}