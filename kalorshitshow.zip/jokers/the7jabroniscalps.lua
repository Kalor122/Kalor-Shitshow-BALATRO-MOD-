SMODS.Joker{ --The 7 Jabroni Scalps
    key = "the7jabroniscalps",
    config = {
        extra = {
            Xmult = 1.75
        }
    },
    loc_txt = {
        ['name'] = 'The 7 Jabroni Scalps',
        ['text'] = {
            [1] = '* You called for help...',
            [2] = '* {X:red,C:white}X1.75{} Mult for every {C:attention}Jabroni{} joker'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 7,
        y = 3
    },
    cost = 7,
    rarity = "kalorshi_kalor",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.other_joker  then
            if (function()
    return context.other_joker.config.center.rarity == "kalorshi_jabroni"
end)() then
                return {
                    Xmult = card.ability.extra.Xmult
                }
            end
        end
    end
}