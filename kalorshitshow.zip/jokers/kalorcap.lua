SMODS.Joker{ --Kalor Cap
    key = "kalorcap",
    config = {
        extra = {
            money = 0
        }
    },
    loc_txt = {
        ['name'] = 'Kalor Cap',
        ['text'] = {
            [1] = '{C:money}+1${} Every time a',
            [2] = '{C:attention}playing card{} is added to deck',
            [3] = '{C:inactive}(Current: {C:money}+#1#${}{C:inactive}){}{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 5,
        y = 1
    },
    cost = 5,
    rarity = "kalorshi_kalor",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.money}}
    end,

    calculate = function(self, card, context)
        if context.playing_card_added  then
                return {
                    func = function()
                    card.ability.extra.money = (card.ability.extra.money) + 1
                    return true
                end
                }
        end
        if context.cardarea == G.jokers and context.joker_main  then
                return {
                    dollars = card.ability.extra.money
                }
        end
    end
}