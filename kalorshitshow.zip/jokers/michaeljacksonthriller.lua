SMODS.Joker{ --Michael Jackson - Thriller
    key = "michaeljacksonthriller",
    config = {
        extra = {
            chips = 30
        }
    },
    loc_txt = {
        ['name'] = 'Michael Jackson - Thriller',
        ['text'] = {
            [1] = '{C:blue}+30{} Chips is scored card is a {C:attention}3{}',
            [2] = '{C:inactive}(Three)ller{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 4,
        y = 2
    },
    cost = 4,
    rarity = "kalorshi_album",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if context.other_card:get_id() == 3 then
                return {
                    chips = card.ability.extra.chips,
                    message = "Thriller!"
                }
            end
        end
    end
}