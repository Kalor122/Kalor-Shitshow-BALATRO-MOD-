SMODS.Joker{ --Jabrony Mike
    key = "jabronymike",
    config = {
        extra = {
            chips = 0
        }
    },
    loc_txt = {
        ['name'] = 'Jabrony Mike',
        ['text'] = {
            [1] = 'The jar keeps being filled with {C:attention}unkown white liquid{}',
            [2] = 'Gains {C:blue}+5{} Chips evey hand',
            [3] = '{C:inactive}(Current: {}{C:blue}+#1#{} {C:inactive}Chips){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 0,
        y = 1
    },
    cost = 5,
    rarity = "kalorshi_jabroni",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.chips}}
    end,

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
                card.ability.extra.chips = (card.ability.extra.chips) + 5
                return {
                    message = "CUUUUUUUUUUUUUM",
                    extra = {
                        chips = card.ability.extra.chips,
                        colour = G.C.CHIPS
                        }
                }
        end
    end
}