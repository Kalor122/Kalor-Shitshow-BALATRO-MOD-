SMODS.Joker{ --The Choicest Voice
    key = "thechoicestvoice",
    config = {
        extra = {
            j1 = 1,
            odds = 4,
            dollars = 1000
        }
    },
    loc_txt = {
        ['name'] = 'The Choicest Voice',
        ['text'] = {
            [1] = '{C:attention}5{} judges will {C:attention}judge{} your actions on this round',
            [2] = 'If all of them say {C:green}Yes{}, you get {C:money}1000${}',
            [3] = 'If all of them say {C:hearts}No{}, you {C:hearts}die{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 8,
        y = 3
    },
    cost = 8,
    rarity = "kalorshi_kalor",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    set_ability = function(self, card, initial)
        card:set_eternal(true)
    end,

    calculate = function(self, card, context)
        if context.end_of_round and context.game_over == false and context.main_eval  then
            if true then
                if SMODS.pseudorandom_probability(card, 'group_0_f07db90b', 1, card.ability.extra.odds, 'j_kalorshi_thechoicestvoice') then
                      SMODS.calculate_effect({func = function()
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "No", colour = G.C.RED})
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.5,
                    func = function()
                        if G.STAGE == G.STAGES.RUN then 
                          G.STATE = G.STATES.GAME_OVER
                          G.STATE_COMPLETE = false
                        end
                    end
                }))
                
                return true
            end}, card)
                  end
            end
        end
        if context.starting_shop  then
                return {
                    dollars = card.ability.extra.dollars,
                    message = "Yes"
                }
        end
    end
}