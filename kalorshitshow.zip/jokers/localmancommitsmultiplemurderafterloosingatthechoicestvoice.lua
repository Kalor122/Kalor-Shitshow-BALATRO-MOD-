SMODS.Joker{ --Local Man Commits Multiple Murder After Loosing At The Choicest Voice
    key = "localmancommitsmultiplemurderafterloosingatthechoicestvoice",
    config = {
        extra = {
            dollars = 2000,
            yes = 0,
            no = 0
        }
    },
    loc_txt = {
        ['name'] = 'Local Man Commits Multiple Murder After Loosing At The Choicest Voice',
        ['text'] = {
            [1] = '{C:hearts}Kills{} all {C:attention}The Choicest Voice{} judges,',
            [2] = 'collecting {C:attention}double{} the prize'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 0,
        y = 2
    },
    cost = 9,
    rarity = "kalorshi_kalor",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.setting_blind  then
                return {
                    func = function()
                local target_joker = nil
                for i, joker in ipairs(G.jokers.cards) do
                    if joker.config.center.key == "j_kalorshi_thechoicestvoice" and not joker.getting_sliced then
                        target_joker = joker
                        break
                    end
                end
                
                if target_joker then
                    if target_joker.ability.eternal then
                        target_joker.ability.eternal = nil
                    end
                    target_joker.getting_sliced = true
                    G.E_MANAGER:add_event(Event({
                        func = function()
                            target_joker:start_dissolve({G.C.RED}, nil, 1.6)
                            return true
                        end
                    }))
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "FUCK YOU!!!!!!!", colour = G.C.RED})
                end
                    return true
                end,
                    extra = {
                        dollars = card.ability.extra.dollars,
                        colour = G.C.MONEY,
                        extra = {
                            func = function()
                card:start_dissolve()
                return true
            end,
                            message = "Destroyed!",
                            colour = G.C.RED
                        }
                        }
                }
        end
    end
}