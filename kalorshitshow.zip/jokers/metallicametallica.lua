SMODS.Joker{ --Metallica - Metallica
    key = "metallicametallica",
    config = {
        extra = {
            mult = 10
        }
    },
    loc_txt = {
        ['name'] = 'Metallica - Metallica',
        ['text'] = {
            [1] = '{C:red}+10{} Mult if scored card has a',
            [2] = '{C:spades}black suit{} {C:inactive}({}{C:clubs}Clubs{} {C:inactive}or{} {C:spades}Spades{}{C:inactive}){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 3,
        y = 2
    },
    cost = 7,
    rarity = "kalorshi_album",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if context.other_card:is_suit("Spades") or context.other_card:is_suit("Clubs") then
                return {
                    mult = card.ability.extra.mult,
                    message = "Enter Night!"
                }
            end
        end
    end
}