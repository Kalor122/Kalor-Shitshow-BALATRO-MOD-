SMODS.Joker{ --Monopoly For Sore Losers
    key = "monopolyforsorelosers",
    config = {
        extra = {
            Xmult = 1.5,
            Xmult2 = 1.5,
            Xmult3 = 1.5,
            Xmult4 = 1.5
        }
    },
    loc_txt = {
        ['name'] = 'Monopoly For Sore Losers',
        ['text'] = {
            [1] = '{X:red,C:white}X1.5{} Mult if scored card\'s {C:attention}suit{}',
            [2] = 'has less than {C:attention}10{} cards'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 6,
        y = 2
    },
    cost = 8,
    rarity = "kalorshi_kalor",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if (context.other_card:is_suit("Spades") and (function()
    local count = 0
    for _, playing_card in pairs(G.playing_cards or {}) do
        if playing_card:is_suit("Spades") then
            count = count + 1
        end
    end
    return count < 10
end)()) then
                return {
                    Xmult = card.ability.extra.Xmult
                }
            elseif (context.other_card:is_suit("Hearts") and (function()
    local count = 0
    for _, playing_card in pairs(G.playing_cards or {}) do
        if playing_card:is_suit("Hearts") then
            count = count + 1
        end
    end
    return count < 10
end)()) then
                return {
                    Xmult = card.ability.extra.Xmult2
                }
            elseif (context.other_card:is_suit("Diamonds") and (function()
    local count = 0
    for _, playing_card in pairs(G.playing_cards or {}) do
        if playing_card:is_suit("Diamonds") then
            count = count + 1
        end
    end
    return count < 10
end)()) then
                return {
                    Xmult = card.ability.extra.Xmult3
                }
            elseif (context.other_card:is_suit("Clubs") and (function()
    local count = 0
    for _, playing_card in pairs(G.playing_cards or {}) do
        if playing_card:is_suit("Clubs") then
            count = count + 1
        end
    end
    return count < 10
end)()) then
                return {
                    Xmult = card.ability.extra.Xmult4
                }
            end
        end
    end
}