SMODS.Joker{ --Limp Bizkit - Three Dollar Bill, Yall
    key = "limpbizkitthreedollarbillyall",
    config = {
        extra = {
            odds = 3,
            dollars = 3
        }
    },
    loc_txt = {
        ['name'] = 'Limp Bizkit - Three Dollar Bill, Yall',
        ['text'] = {
            [1] = '{C:green}1 in 3{} chance to give {C:money}+3${} when',
            [2] = 'a card is scored'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 9,
        y = 1
    },
    cost = 3,
    rarity = "kalorshi_album",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if true then
                if SMODS.pseudorandom_probability(card, 'group_0_4de71eb2', 1, card.ability.extra.odds, 'j_kalorshi_limpbizkitthreedollarbillyall') then
                      SMODS.calculate_effect({dollars = card.ability.extra.dollars}, card)
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Pollution!", colour = G.C.MONEY})
                  end
            end
        end
    end
}