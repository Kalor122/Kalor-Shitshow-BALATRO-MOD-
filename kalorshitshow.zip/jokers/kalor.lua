SMODS.Joker{ --Kalor
    key = "kalor",
    config = {
        extra = {
            Xmult = 1.75
        }
    },
    loc_txt = {
        ['name'] = 'Kalor',
        ['text'] = {
            [1] = '{X:red,C:white}X1.75{} Mult for every {C:attention}Kalor{} joker'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 4,
        y = 1
    },
    cost = 5,
    rarity = "kalorshi_kalor",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.other_joker  then
            if (function()
    return context.other_joker.config.center.rarity == "kalorshi_kalor"
end)() then
                return {
                    Xmult = card.ability.extra.Xmult
                }
            end
        end
    end
}