SMODS.Joker{ --Gift Box
    key = "giftbox",
    config = {
        extra = {
            odds = 4,
            eternal = 0,
            ignore = 0
        }
    },
    loc_txt = {
        ['name'] = 'Gift Box',
        ['text'] = {
            [1] = 'Contains a {C:attention}random eternal joker{}',
            [2] = '{C:green}1 in 4{} chance at the',
            [3] = 'start of round to {C:attention}open{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 6,
        y = 0
    },
    cost = 4,
    rarity = "kalorshi_kalor",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.setting_blind  then
            if true then
                if SMODS.pseudorandom_probability(card, 'group_0_5df8e4ae', 1, card.ability.extra.odds, 'j_kalorshi_giftbox') then
                      SMODS.calculate_effect({func = function()
                card:start_dissolve()
                return true
            end}, card)
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Destroyed!", colour = G.C.RED})
                        SMODS.calculate_effect({func = function()
            local created_joker = true
            G.E_MANAGER:add_event(Event({
                func = function()
                    local joker_card = SMODS.add_card({ set = 'Joker' })
                    if joker_card then
                        
                        joker_card:add_sticker('eternal', true)
                    end
                    
                    return true
                end
            }))
            
            if created_joker then
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Happy Birthday!", colour = G.C.BLUE})
            end
            return true
        end}, card)
                  end
            end
        end
    end
}