SMODS.Joker{ --Megadeth - Th1rt3en
    key = "megadethth1rt3en",
    config = {
        extra = {
            Xmult = 13
        }
    },
    loc_txt = {
        ['name'] = 'Megadeth - Th1rt3en',
        ['text'] = {
            [1] = '{X:red,C:white}X13{} Mult if scored hand',
            [2] = 'contains an {C:attention}Ace{} and a {C:attention}3{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 2,
        y = 2
    },
    cost = 13,
    rarity = "kalorshi_album",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if ((function()
    local rankCount = 0
    for i, c in ipairs(context.scoring_hand) do
        if c:get_id() == 14 then
            rankCount = rankCount + 1
        end
    end
    
    return rankCount >= 1
end)() and (function()
    local rankCount = 0
    for i, c in ipairs(context.scoring_hand) do
        if c:get_id() == 3 then
            rankCount = rankCount + 1
        end
    end
    
    return rankCount >= 1
end)()) then
                return {
                    Xmult = card.ability.extra.Xmult,
                    message = "Thirteen ways to see the devil in my eyes..."
                }
            end
        end
    end
}