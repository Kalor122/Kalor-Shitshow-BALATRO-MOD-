SMODS.Joker{ --Tax Evasion
    key = "taxevasion",
    config = {
        extra = {
            yes = 0,
            odds = 4,
            tax_evasion = 0
        }
    },
    loc_txt = {
        ['name'] = 'Tax Evasion',
        ['text'] = {
            [1] = '{C:green}1 in 4{} chance to {C:hearts}evade taxes{}',
            [2] = 'at the end of round if you own',
            [3] = '{C:attention}Tax Accountant{}',
            [4] = 'If it\'s {C:hearts}unsuccessful{}, you go to {C:hearts}jail{} {C:inactive}(die){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 6,
        y = 3
    },
    cost = 5,
    rarity = "kalorshi_kalor",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    in_pool = function(self, args)
          return (
          not args 
            
          or args.source == 'sho' or args.source == 'buf' or args.source == 'jud' or args.source == 'rif' or args.source == 'rta' or args.source == 'sou' or args.source == 'uta' or args.source == 'wra'
          )
          and G.GAME.pool_flags.kalorshi_tax_evasion
      end,

    calculate = function(self, card, context)
        if context.setting_blind  then
            if (function()
      for i = 1, #G.jokers.cards do
          if G.jokers.cards[i].config.center.key == "j_kalorshi_taxaccountant" then
              return true
          end
      end
      return false
  end)() then
                if SMODS.pseudorandom_probability(card, 'group_0_0c7b0315', 1, card.ability.extra.odds, 'j_kalorshi_taxevasion') then
                      SMODS.calculate_effect({func = function()
                    card.ability.extra.yes = 1
                    return true
                end}, card)
                  end
            end
        end
        if context.end_of_round and context.game_over == false and context.main_eval  then
            if (card.ability.extra.yes or 0) == 1 then
                G.GAME.pool_flags.kalorshi_tax_evasion = true
                return {
                    message = "Success!",
                    extra = {
                        func = function()
                card:start_dissolve()
                return true
            end,
                            message = "Destroyed!",
                        colour = G.C.RED
                        }
                }
            elseif (card.ability.extra.yes or 0) == 0 then
                G.GAME.pool_flags.kalorshi_tax_evasion = false
                return {
                    message = "Failure!",
                    extra = {
                        func = function()
                
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.5,
                    func = function()
                        if G.STAGE == G.STAGES.RUN then 
                          G.STATE = G.STATES.GAME_OVER
                          G.STATE_COMPLETE = false
                        end
                    end
                }))
                
                return true
            end,
                        colour = G.C.GREEN,
                        extra = {
                            func = function()
                card:start_dissolve()
                return true
            end,
                            message = "Destroyed!",
                            colour = G.C.RED
                        }
                        }
                }
            end
        end
    end
}