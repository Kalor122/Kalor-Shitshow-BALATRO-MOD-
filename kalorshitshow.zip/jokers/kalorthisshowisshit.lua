SMODS.Joker{ --Kalor, this show is shit
    key = "kalorthisshowisshit",
    config = {
        extra = {
            chips = 50
        }
    },
    loc_txt = {
        ['name'] = 'Kalor, this show is shit',
        ['text'] = {
            [1] = '{C:blue}+50{} Chips for every {C:purple}Kalor Shitshow{} joker'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 6,
        y = 1
    },
    cost = 6,
    rarity = "kalorshi_kalor",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.other_joker  then
            if ((function()
    return context.other_joker.config.center.rarity == "kalorshi_kalor"
end)() or (function()
    return context.other_joker.config.center.rarity == "kalorshi_jabroni"
end)() or (function()
    return context.other_joker.config.center.rarity == "kalorshi_super_kalor"
end)()) then
                return {
                    chips = card.ability.extra.chips
                }
            end
        end
    end
}