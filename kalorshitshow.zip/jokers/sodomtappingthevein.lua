SMODS.Joker{ --Sodom - Tapping The Vein
    key = "sodomtappingthevein",
    config = {
        extra = {
            chips = 10
        }
    },
    loc_txt = {
        ['name'] = 'Sodom - Tapping The Vein',
        ['text'] = {
            [1] = '{C:blue}+10{} Chips if scored hand is a {C:hearts}Heart{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 3,
        y = 3
    },
    cost = 6,
    rarity = "kalorshi_album",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if context.other_card:is_suit("Hearts") then
                return {
                    chips = card.ability.extra.chips
                }
            end
        end
    end
}