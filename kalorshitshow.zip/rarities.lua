SMODS.Rarity {
    key = "kalor",
    pools = {
        ["Joker"] = true
    },
    default_weight = 0.5,
    badge_colour = HEX('9013fe'),
    loc_txt = {
        name = "Kalor"
    },
    get_weight = function(self, weight, object_type)
        return weight
    end,
}

SMODS.Rarity {
    key = "jabroni",
    pools = {
        ["Joker"] = true
    },
    default_weight = 0.5,
    badge_colour = HEX('ed91ff'),
    loc_txt = {
        name = "Jabroni"
    },
    get_weight = function(self, weight, object_type)
        return weight
    end,
}

SMODS.Rarity {
    key = "super_kalor",
    pools = {
        ["Joker"] = true
    },
    default_weight = 0.01,
    badge_colour = HEX('2f0058'),
    loc_txt = {
        name = "SUPER Kalor"
    },
    get_weight = function(self, weight, object_type)
        return weight
    end,
}

SMODS.Rarity {
    key = "album",
    pools = {
        ["Joker"] = true
    },
    default_weight = 0.5,
    badge_colour = HEX('4a4a4a'),
    loc_txt = {
        name = "Album"
    },
    get_weight = function(self, weight, object_type)
        return weight
    end,
}